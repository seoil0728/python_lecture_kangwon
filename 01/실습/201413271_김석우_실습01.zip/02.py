a = input("입력해주세요!")
b = input("입력해주세요!")
c = input("입력해주세요!")

print(a)
print(b)
print(c)
print(b)
print(a)