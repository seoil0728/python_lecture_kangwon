def myAddition(x):
  return x+1

def addOne():
  n = int(input("Please input number : "))
  print(myAddition(n))

addOne()